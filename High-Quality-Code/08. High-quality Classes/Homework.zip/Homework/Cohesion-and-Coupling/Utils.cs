﻿using System;

namespace CohesionAndCoupling
{
    static class Utils
    {
    }
}
