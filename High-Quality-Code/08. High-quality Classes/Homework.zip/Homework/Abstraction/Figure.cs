﻿using System;

namespace Abstraction
{
    abstract class Figure
    {
        public abstract double Area { get;}
        public abstract double Perimeter { get; }
    }
}
