﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control_Structures__Cond.Statements__Loops
{
    public class Vegetable
    {
        public bool HasBeenPeeled()
        {
            return true;
        }

        public bool IsRotten()
        {
            return false;
        }
    }
}
